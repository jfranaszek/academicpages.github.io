# setup -------------------------------------------------------------------

rm(list = ls())

#install.packages("readxl")
library(readxl)


# import io files ---------------------------------------------------------


url <- "https://stat.gov.pl/download/gfx/portalinformacyjny/pl/defaultaktualnosci/5481/7/2/1/bilans_przeplywow_miedzygaleziowych_2010.xls"
file <- "bilans_przeplywow_miedzygaleziowych_2010.xls"

if (file.exists(file) == FALSE) {
  httr::GET(url, httr::write_disk(file))
}

#io
readxl::read_excel(file, sheet = "Tabl. 1", range = "D11:CB88", col_names = TRUE) -> io
as.matrix(io) -> io
unname(io) -> io

#X
readxl::read_excel(file, sheet = "Tabl. 1", range = "D98:CB98", col_names = FALSE) -> X
as.numeric(X) -> X

#names
readxl::read_excel(file, sheet = "Tabl. 1", range = "D7:CB7", col_names = FALSE) -> names
as.character(names) -> names


# analysis ----------------------------------------------------------------

#number of sectors
N <- nrow(io)
#final output
Y <- X - rowSums(io)
#value added
va <- X - colSums(io)

#gdp
cat("GDP = ", sum(Y))
#check general equlibrium 
sum(Y) == sum(va)

#cost matrix
A <- matrix(0, nrow = N, ncol = N)
for (i in 1:N) {
  A[, i] <- io[, i]/X[i]
}

#check
A
colSums(A)

#sometimes there are Na, as there is no material costs od some sectors
A <- replace(A, is.na(A), 0)

# Leontief matrix
L <- diag(N) - A

View(round(L, 2))

#Leontief model LX=Y
#check
L %*% X - Y


# simulations -------------------------------------------------------------


#1 - Agriculture
X1 <- X 
X1[1] <- X1[1]*0.75
Y1 <- L %*% X1
data.frame(names, perchange = round(Y1/Y - 1, 3))
sum(Y1)/sum(Y) - 1


#2 - Tobacoo
names[8]
X2 <- X 
X2[8] <- X[8]*0
Y2 <- L %*% X2
data.frame(names, perchange = round(Y2/Y - 1, 3))
sum(Y2)/sum(Y) - 1


#3 - prices in energy sector
#price model ingredients
iA <- solve(diag(N) - t(A))
vc <- va/X
#check
p <- iA %*% vc
p
#What does the vector of ones mean?

names[30]
vc3 <- vc
vc3[30] <- vc[30]*1.25
p3 <- iA %*% vc3
data.frame(names, perchange = round(p3/p - 1, 3))
cat("overall price change = ", weighted.mean(p3/p - 1, w = X))


#4 - prices in oil sector
names[5]
vc4 <- vc
vc4[5] <- vc[5]*1.25
p4 <- iA %*% vc4
data.frame(names, perchange = round(p4/p - 1, 3))
cat("overall price change = ", weighted.mean(p4/p - 1, w = X))

#comparison #3 and #4
data.frame(names, energy = round(p3/p - 1, 3), oil = round(p4/p - 1, 3))
cat("overall price change, energy = ", weighted.mean(p3/p - 1, w = X), ", oil = ", weighted.mean(p4/p - 1, w = X))
