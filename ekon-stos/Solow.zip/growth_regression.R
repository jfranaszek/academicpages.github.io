# setup -------------------------------------------------------------------

rm(list = ls())

#jak nie masz AER to wykonaj linię poniżej:
#install.packages("AER")
library(AER)

#install.packages("stargazer")
library(stargazer)


# import data -------------------------------------------------------------


data(GrowthDJ)
help("GrowthDJ")
# por. Mankiw, N.G, Romer, D., and Weil, D.N. (1992). A Contribution to the Empirics of Economic Growth. Quarterly Journal of Economics, 107, 407?437.

df <- GrowthDJ
df$dl_gdp <- log(df$gdp85) - log(df$gdp60)


# regression analysis -----------------------------------------------------


#regresja 1 (podstawowy)
model1	= lm(dl_gdp ~ log(gdp60), data = df)
summary(model1)

-log(1 + coef(model1)["log(gdp60)"])/(85 - 60)

plot(x = log(df$gdp60), df$dl_gdp)

summary(lm(dl_gdp ~ log(gdp60), data = df, subset = df$oecd == "yes"))

#regresja 2 (pełny model)
df$par <- df$popgrowth/100 + df$popgrowth/100 + 0.03
model2	= lm(dl_gdp ~ log(gdp60) + log(invest/100) + log(par), data = df)
summary(model2)
stargazer(model1, model2, type = "text")

-log(1 + coef(model2)["log(gdp60)"])/(85 - 60)



#regresja 3 (non-oil)
model3	= lm(dl_gdp ~ log(gdp60) + log(invest/100) + log(par), data = df, subset = df$oil == "no")
summary(model3)
stargazer(model1, model2, model3, type = "text")

-log(1 + coef(model3)["log(gdp60)"])/(85 - 60)

df_nonoil <- df[df$oil == "no", ]
plot(x = log(df_nonoil$gdp60), df_nonoil$dl_gdp)



#regresja 4 (OECD)
model4	= lm(dl_gdp ~ log(gdp60) + log(invest/100) + log(par), data = df, subset = df$oecd == "yes")
summary(model4)
stargazer(model1, model2, model3, model4, type = "text")

-log(1 + coef(model4)["log(gdp60)"])/(85 - 60)

df_oecd <- df[df$oecd == "yes", ]
plot(x = log(df_oecd$gdp60), df_oecd$dl_gdp)



#regresja 5 (schooling)
model5	= lm(dl_gdp ~ log(gdp60) + log(invest/100) + log(par) + log(school), data = df)
summary(model5)

-log(1 + coef(model5)["log(gdp60)"])/(85 - 60)

stargazer(model1, model2, model3, model4, model5, type = "text")
