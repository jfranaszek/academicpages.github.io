# setup -------------------------------------------------------------------

rm(list = ls())

#install.packages("quantmod")
library(quantmod)
#install.packages("tsbox")
library(tsbox)
#install.packages("seasonal")
library(seasonal)
#install.packages("mFilter")
library(mFilter)


# data import -------------------------------------------------------------
#https://fred.stlouisfed.org/series/GDPC1


#get CPI and GDP data
getSymbols(c("CPIAUCSL", "GDPC1"), src = "FRED")
#convert monthly CPI to quarterly frequency
ts_frequency(CPIAUCSL, to = "quarter", aggregate = "mean") -> CPIQ

# seasonality -------------------------------------------------------------

#seasonal adjustment
getSymbols("NA000334Q", src = "FRED")
plot(NA000334Q)
seas(ts_ts(NA000334Q)) -> gdp_object
final(gdp_object) -> gdp_sa

ts_c(gdp_nsa = log(NA000334Q), gdp_sa = log(gdp_sa)) -> gdp_comparison
#plots
plot(gdp_comparison, col = c("red1", "black"), lwd = c(1,2), main = "level")
plot(ts_diff(gdp_comparison), col = c("red1", "black"), lwd = c(1,2), main = "quarterly dynamic")
plot(ts_diffy(gdp_comparison), col = c("red1", "black"), lwd = c(1,2), main = "annual dynamic")


# spectral analysis -------------------------------------------------------

#autocorrelation function
acf(log(GDPC1),lag.max = 40)

#spectrum
spectrum(log(GDPC1), log = "no")
#The function spectrum is a wrapper for calculating the periodogram (i.e., an estimate of the spectral density) from time series. There are a couple issues that need to keep in mind:
# - spectrum calculates the frequency axis in terms of cycles per sampling interval; it makes more sense to convert to cycles per unit time
# - the spectrum will be far more interpretable if it is smoothed
#   - Use the argument spans, which specifies the parameter(s) for the what is known as the modified Daniell kernel for smoothing the spectrum
#   - Modified Daniell kernel is essentially just a running average (see code below for a sense of what these parameters do)
#   - No hard-and-fast rule for how to do this (try a couple different values)
#   - the higher the number of spans, the more smoothing and the lower the peaks of the spectrum will be
# - the default for spectrum is to calculate the spectrum on a log-scale
# - Use the argument log="no" to change this default
# - The spectrum needs to be multiplied by 2 to make it actually equal to variance


#log of GDP
spectral <- spectrum(log(GDPC1), plot = FALSE)
plot(spectral, log = "no")
trunc(length(spectral$freq)/3) -> zoom
plot(spectral$freq[1:zoom], spectral$spec[1:zoom], type = "l", xlab = "frequency", ylab = "spectrum")
axis(side = 3, 
     at = spectral$freq[seq(1,zoom, by = 4)], 
     labels = round(1/spectral$freq[seq(1,zoom, by = 4)], digits = 1)) #quarterly axis

#log of GDP - smoothed
kernel("modified.daniell", c(2, 2))
spectral <- spectrum(log(GDPC1), span = c(2, 2), plot = FALSE)
plot(spectral, log = "no")
trunc(length(spectral$freq)/3) -> zoom
plot(spectral$freq[1:zoom], spectral$spec[1:zoom], type = "l", xlab = "frequency", ylab = "spectrum")
axis(side = 3, 
     at = spectral$freq[seq(1,zoom, by = 4)], 
     labels = round(1/spectral$freq[seq(1,zoom, by = 4)], digits = 1)) #quarterly axis

#y-o-y growth rate of GDP
spectral <- spectrum(na.omit(ts_diffy(GDPC1)), 
                     span = c(2, 2), plot = FALSE)
plot(spectral$freq[1:zoom], spectral$spec[1:zoom], type = "l", xlab = "frequency", ylab = "spectrum")
axis(side = 3, 
     at = spectral$freq[seq(1,zoom, by = 4)], 
     labels = round(1/4*1/spectral$freq[seq(1,zoom, by = 4)], digits = 1)) #annual axis

#y-o-y growth rate of CPI
spectral <- spectrum(na.omit(ts_diffy(CPIQ)), 
                     span = c(2, 2), plot = FALSE)
plot(spectral$freq[1:zoom], spectral$spec[1:zoom], type = "l", xlab = "frequency", ylab = "spectrum")
axis(side = 3, 
     at = spectral$freq[seq(1,zoom, by = 4)], 
     labels = round(1/4*1/spectral$freq[seq(1,zoom, by = 4)], digits = 1)) #annual axis


# filtering ---------------------------------------------------------------

#create dataset
ts_c(log(GDPC1), log(CPIQ)) -> df
df <- na.omit(df)
colnames(df) <- c("GDP", "CPI")
#correlation
cor(df)
#correlation is dominated by trend

#HP filter
gdp_hp <- mFilter::hpfilter(log(GDPC1), type = "frequency", freq = 10*4) # 10 years in quarters
# or  lambda = (2*sin(pi/frequency))^{-4}.
plot(gdp_hp$cycle, type = "l")


#Christiano-Fitzgerald filter
#GDP
mFilter::cffilter(log(GDPC1), pl = 8, pu = 40, root = TRUE, drift = FALSE) -> gdp_ccf
plot(gdp_ccf$cycle, type = "l", ylab = "log(GDP) cycle")

#HPand CCF comparison
ts.plot(cbind(gdp_ccf$cycle, gdp_hp$cycle), col = c("red", "blue"))

#parametrization of a time series
beg = start(ts_ts(GDPC1))
freq = frequency(ts_ts(GDPC1))
#plot cycle
plot(ts(gdp_ccf$cycle, start = beg, frequency = freq), type = "l", ylab = "log(GDP) cycle")

#CPI
mFilter::cffilter(log(CPIQ), pl = 8, pu = 40, root = TRUE, drift = FALSE) -> cpi_ccf
plot(ts(cpi_ccf$cycle, start = beg, frequency = freq), type = "l", ylab = "log(CPI) cycle")

#correlation
ts_c(ts(gdp_ccf$cycle, start = beg, frequency = freq),
     ts(cpi_ccf$cycle, start = beg, frequency = freq)) -> df
df <- na.omit(df)
colnames(df) <- c("GDP", "CPI")
cor(df)

#relative standard deviations
ts.plot(df, col = c("red2", "blue3"), lwd = 2)
sd_gdp <- sd(df[, "GDP"])
sd_cpi <- sd(df[, "CPI"])
sd_cpi/sd_gdp

